#!/bin/bash
python3 ~/klipper/scripts/calibrate_shaper.py /tmp/calibration_data_y_*.csv -o ~/printer_data/config/calibration_shaper_resonance/shaper_calibrate_y.png